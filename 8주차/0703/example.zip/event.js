window.addEventListener("load", function () {
    let result = document.querySelector("input[id=result]");
    let btns = document.querySelectorAll("button");

    result.style.backgroundColor = "lightgray";
    result.value = 0;

    //num = parseInt(result.value); //문자->정수
    //num = Number(result.value);   //문자->숫자

    let num = 5;
    let op;

    for (let i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", () => {
            switch (btns[i].innerHTML) {
                case "=": {                    
                    if (op == '+')
                        result.value += num;
                    else if (op == '-')
                        result.value -= num;
                    else if (op == '*')
                        result.value *= num;
                    else if (op == '/')
                        result.value /= num;
                    else
                        result.value = num;
                    break;
                }
                case "C":
                    result.value = 0;
                    op = undefined;
                    break;
                case "+":
                    op = '+';
                    break;
                case "-":                    
                    op = '-';
                    break;
                case "*":
                    op = '*';
                    break;
                case "/":
                    op = '/';
                    break;
                case "0":
                    num = 0;
                    break;
                case "1":
                    num = 1;
                    break;
                case "2":
                    num = 2;
                    break;
                case "3":
                    num = 3;
                    break;
                case "4":
                    num = 4;
                    break;
                case "5":
                    num = 5;
                    break;
                case "6":
                    num = 6;
                    break;
                case "7":
                    num = 7;
                    break;
                case "8":
                    num = 8;
                    break;
                case "9":
                    num = 9;
                    break;

                default:
            }
        }); //switch
    } //for



    let checkAllObj = this.document.querySelector(
        'fieldset.all > input[type=checkbox]');
    let checkNumObj = this.document.querySelectorAll(
        'fieldset.each > input[type=checkbox]');
    
    //---all checkbox객체가 클릭됐을때 START--
    checkAllObj.addEventListener('click', (e)=>{
        // console.log(e.target.checked)
        checkNumObj.forEach((chk)=>{
            chk.checked = e.target.checked;
        }) 
    })

    //---all checkbox객체가 클릭됐을때 END--

});
