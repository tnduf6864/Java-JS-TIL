// plus(5, 30);

// function plus(a, b) {
//     console.log(a + b);
// }

// var a = plus(3, 10);
// console.log(a);

// var f1 = function() {
//     console.log('안녕');
// }

// f2 = f1;
// f2();

// var f3 =  function(a) {
//     console.log(a)
// }

// f3(2);
// f3(true);
// f3(f1);

// var f4 = function(a) {
//     a();
// }

// f4(function() {
//     console.log('콜백함수');
// });

// arr5.forEach(function() {

// })



f5( (a, i)=> {
    return (a * i);
}, 2, 3)

