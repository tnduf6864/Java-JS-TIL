window.addEventListener('load', function () {
  let result = document.querySelector('input[id=result]');
  let btns = document.querySelectorAll('button');

  result.value = 0;
  result.style.backgroundColor = 'lightgray';

  calculate(result, btns);

  let checkAllObj = this.document.querySelector(
    'fieldset.all > input[type=checkbox]'
  );
  let checkNumObj = this.document.querySelectorAll(
    'fieldset.each > input[type=checkbox]'
  );

  //---all checkbox객체가 클릭됐을때 START--
  checkAllObj.addEventListener('click', (e) => {
    // console.log(e.target.checked)
    checkNumObj.forEach((chk) => {
      chk.checked = e.target.checked;
    });
  });
  //---all checkbox객체가 클릭됐을때 END--

  //-- 동물을 선택했을때 할 일 START--
  let petTypeObj = document.querySelector('div.hit>select.petType');
  let petSound = document.querySelectorAll('div.hit>select.petSound>option');
  let petInfo = document.querySelector('div.hit>select.petInfo');
  petInfo.innerHTML = '<option>' + '몸 풀기' + '</option>';

  petTypeObj.addEventListener('change', (e) => {
    attack = ['만지기', '쓰다듬기', '껴안기', '주먹'];

    attack = [
      { sound: '만지기', damage: '+1' },
      { sound: '쓰다듬기', damage: '+3' },
      { sound: '껴안기', damage: '+10' },
      { sound: '주먹', damage: '-999' },
    ];

    switch (e.target.value) {
      case '공주':
        petSound[1].selected = true;
        for (i = 0; i < 2; i++)
          petInfo.innerHTML += `<option>${attack[i].sound}</option>`;
        break;
      case '훠훠':
        petSound[2].selected = true;

        let options = document.querySelectorAll('div.hit > select.petInfo > option');
        options.forEach((value) => {
          petInfo.removeChild(value);
        });

        attack.forEach((value) => {
          let optionObj = document.createElement('option');
          let txtObj = document.createTextNode(value.sound);
          optionObj.appendChild(txtObj);
          petInfo.appendChild(optionObj);
        });
        break;
      case '쿵쾅':
        petSound[3].selected = true;
        petInfo.innerHTML = '<option>' + attack[0].sound + '</option>';

        break;
      case '쿵쾅2':
        petSound[4].selected = true;
        petInfo.innerHTML = '<option>' + attack[3].sound + '</option>';
        break;
      default:
        petSound[0].selected = true;
        petInfo.innerHTML = '<option>' + '몸 풀기' + '</option>';
        break;
    }
  });
  //-- 동물을 선택했을때 할 일 END--

  //--DOMkeyboard 입력 요소 객체 찾기
  const txtObj = document.querySelector('div.keyboard>input[type=text]');
  //const txtObj = $('div>keyboard>input[type=text]');

  txtObj.addEventListener('keyup', (e) => {
    var str = e.target.value.toUpperCase;
    console.log(e.key + ': ' + str);
  });

  //--전송버튼을 클릭했을 때 할 일 START--
  const btnSubmitObj = document.querySelector('div.form > form > button');

  //TODO: 콘솔에 '전송버튼이 클릭됐습니다!' 출력
  btnSubmitObj.addEventListener('click', (e) => {
    alert('전송버튼이 클릭됐습니다!');
    e.preventDefault();
  });
  //--전송버튼을 클릭했을 때 할 일 END--

  // //--폼의 submit이벤트가 발생했을 때 할 일 START--
  // const formObj = document.querySelector("div.form > form");
  // formObj.addEventListener("submit", () => {
  //   alert("submit이벤트가 발생했습니다~");
  // });
  // //--폼의 submit이벤트가 발생했을 때 할 일 END--

  //--<a> 요소의 click이벤트가 발생했을 때 링크 넘어가기 prevent START--

  var divCnt = 0;
  document.querySelector('div.link').addEventListener('click', (e) => {
    var divObj = document.querySelector('.link');
    if (divCnt % 2 == 0) {
      divObj.style.backgroundColor = 'pink';
      divCnt++;
    } else {
      divObj.style.backgroundColor = 'lightskyblue';
      divCnt++;
    }
  });

  const aTag = document.querySelector('div.link > a');
  aTag.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
  });
});
//onload

function calculate(result, btns) {
  let num = 5;
  let op;

  for (let i = 0; i < btns.length; i++) {
    btns[i].addEventListener('click', () => {
      switch (btns[i].innerHTML) {
        case '=': {
          if (op == '+') result.value += num;
          else if (op == '-') result.value -= num;
          else if (op == '*') result.value *= num;
          else if (op == '/') result.value /= num;
          else result.value = num;
          break;
        }
        case 'C':
          result.value = 0;
          op = undefined;
          break;
        case '+':
          op = '+';
          break;
        case '-':
          op = '-';
          break;
        case '*':
          op = '*';
          break;
        case '/':
          op = '/';
          break;
        case '0':
          num = 0;
          break;
        case '1':
          num = 1;
          break;
        case '2':
          num = 2;
          break;
        case '3':
          num = 3;
          break;
        case '4':
          num = 4;
          break;
        case '5':
          num = 5;
          break;
        case '6':
          num = 6;
          break;
        case '7':
          num = 7;
          break;
        case '8':
          num = 8;
          break;
        case '9':
          num = 9;
          break;

        default:
      }
    }); //switch
  }
}
